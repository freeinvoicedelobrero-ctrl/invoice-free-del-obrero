# INVOICE FREE DEL OBRERO

**Invoices in your language. Hecho por un obrero.**
Hecho gratis por Roofs by Hopkins, para el emprendedor.

## 👉 [ABRIR LA APP / OPEN THE APP](https://freeinvoicedelobrero-ctrl.github.io/invoice-free-del-obrero/)

https://freeinvoicedelobrero-ctrl.github.io/invoice-free-del-obrero/

### 🧡 Apoya el proyecto / Support the project
Donaciones privadas / Private donations:

**Monero (XMR)**
`89KaatfVCdiSnuoh7cKFPWYSVLzR8TfKjhs4Z6jfhCsGJzaQA2u3RDXNgwxc4W9CqG3bV5g67PAsRVkxHebWA6fxLkWiWw5`

**Pirate Chain (ARRR)**
`pirate1hre8h85r46na4cwzgdaulxpek0x4l2s3q8mxku766y9lj94k575lgvfkkp3r5e94t5vew4xnyx7`

Free, open-source invoicing app for roofers, siding, gutter crews and every trade.
English / Español. Works on any phone, installs to the home screen, and works offline.

## Features / Funciones
- Invoices and estimates (convert estimate → invoice in one tap), numbering you choose
- Clients with **Choose from contacts** (Android Chrome) or **.vcf import** (iPhone and others)
- **Job site address per project**, with "Open in Maps"
- **All invoices per client**: totals, filters, group by job
- Invoice list with **Unpaid / Paid** tabs, sorting, due-day counter, status badges and running total
- Record full or partial payments (check, Zelle, cash, crypto, …) — balances update automatically
- **Up to 9 job photos** per invoice (location data removed), added to the PDF
- **My wallet / Mi cartera**: Bitcoin, Lightning, Monero (one subaddress per invoice), Ethereum, USDC/USDT (pick the network), Litecoin, Solana, custom coins, Zelle, Cash App, Venmo, PayPal — QR codes on the invoice and PDF. **Non-custodial**: the app never holds money or keys.
- PDF download and share, CSV import from Invoice2go, CSV export, full JSON backup/restore
- Jobs & balances, reports by month and by client

## Privacy / Privacidad
No accounts, no server, no ads, no trackers. Everything is saved **only on the device**
(localStorage + IndexedDB). Use **More → Import & backup → Download full backup** regularly.
The only outside calls: Google Fonts, the cdnjs libraries, and CoinGecko for live crypto prices.

## Publish free with GitHub Pages / Publicar gratis
1. Create a public repository (for example `invoice-free-del-obrero`).
2. Upload every file in this folder: `index.html`, `manifest.webmanifest`, `sw.js`, `icon.svg`, `icon-192.png`, `icon-512.png`, `README.md`, `LICENSE`.
3. **Settings → Pages → Build and deployment → Source: Deploy from a branch → `main` / `(root)` → Save.**
4. In 1–2 minutes your app is live at `https://YOUR-GITHUB-NAME.github.io/invoice-free-del-obrero/` (replace with your GitHub name).
5. Open it in Chrome on your phone → **Install app** (or ⋮ → Add to Home screen).

When you change files, bump `VERSION` in `sw.js` so phones pick up the update.

## License
MIT — free to use, copy and improve. See `LICENSE`.
