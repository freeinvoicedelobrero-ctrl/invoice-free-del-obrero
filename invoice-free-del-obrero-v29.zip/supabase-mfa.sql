-- Invoice Free del Obrero — enforce 2-step (authenticator app) for email accounts.
-- Run once in Supabase → SQL Editor. Safe to run again.
-- If a user turned on 2-step, their data can only be read/written after they enter the 6-digit code.

create or replace function public.has_verified_mfa()
returns boolean
language sql stable security definer set search_path = public, auth as $$
  select exists (
    select 1 from auth.mfa_factors f
    where f.user_id = auth.uid() and f.status = 'verified'
  );
$$;
revoke all on function public.has_verified_mfa() from public;
grant execute on function public.has_verified_mfa() to authenticated;

drop policy if exists "own row" on public.user_data;
create policy "own row" on public.user_data
  for all to authenticated
  using (
    auth.uid() = user_id
    and ((select auth.jwt()->>'aal') = 'aal2' or not public.has_verified_mfa())
  )
  with check (
    auth.uid() = user_id
    and ((select auth.jwt()->>'aal') = 'aal2' or not public.has_verified_mfa())
  );
